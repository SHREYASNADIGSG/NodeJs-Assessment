const express = require("express");
const {
    createTrade,
    getAllTrades,
    getTradeById,
    methodNotAllowed
} = require("../controllers/tradeController");

const router = express.Router();

router.post("/trades", createTrade);
router.get("/trades", getAllTrades);
router.get("/trades/:id", getTradeById);
router.delete("/trades/:id", methodNotAllowed);
router.patch("/trades/:id", methodNotAllowed);

module.exports = router;
