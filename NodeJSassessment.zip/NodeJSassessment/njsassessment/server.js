const express = require("express");
const dotenv = require("dotenv");
const jwt = require("jsonwebtoken");
const tradeRoutes = require("./routes/tradeRoutes");
require("./config/db");

dotenv.config();
const app = express();
app.use(express.json());


const authMiddleware = (req, res, next) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) {
        return res.status(401).json({ message: "Unauthorized" });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(403).json({ message: "Invalid token" });
    }
};


app.use("/api", authMiddleware, tradeRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(` Server running on port ${PORT}`));
