const jwt = require('jsonwebtoken');
require('dotenv').config();

const token = jwt.sign({ user_id: 1 }, process.env.JWT_SECRET, { expiresIn: '1h' });
console.log("Generated JWT Token:", token);
