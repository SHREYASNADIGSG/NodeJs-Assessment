const db = require("../config/db");

const Trade = {
    create: (trade, callback) => {
        const sql = "INSERT INTO trades SET ?";
        db.query(sql, trade, callback);
    },

    getAll: (filters, callback) => {
        let sql = "SELECT * FROM trades";
        const conditions = [];
        const values = [];

        if (filters.type) {
            conditions.push("type = ?");
            values.push(filters.type);
        }
        if (filters.user_id) {
            conditions.push("user_id = ?");
            values.push(filters.user_id);
        }

        if (conditions.length) {
            sql += " WHERE " + conditions.join(" AND ");
        }

        db.query(sql, values, callback);
    },

    getById: (id, callback) => {
        const sql = "SELECT * FROM trades WHERE id = ?";
        db.query(sql, [id], callback);
    }
};

module.exports = Trade;
