const Trade = require("../models/Trade");
const { v4: uuidv4 } = require("uuid");

exports.createTrade = (req, res) => {
    const { type, user_id, symbol, shares, price, timestamp } = req.body;

    if (!['buy', 'sell'].includes(type)) {
        return res.status(400).json({ message: "Incorrect type provided" });
    }

    if (shares < 1 || shares > 100) {
        return res.status(400).json({ message: "Shares value out of range" });
    }

    const trade = { id: uuidv4(), type, user_id, symbol, shares, price, timestamp };
    
    Trade.create(trade, (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.status(201).json(trade);
    });
};

exports.getAllTrades = (req, res) => {
    const filters = { type: req.query.type, user_id: req.query.user_id };
    
    Trade.getAll(filters, (err, results) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.status(200).json(results);
    });
};

exports.getTradeById = (req, res) => {
    Trade.getById(req.params.id, (err, results) => {
        if (err) return res.status(500).json({ message: "Database error" });
        if (results.length === 0) {
            return res.status(404).json({ message: "ID not found" });
        }
        res.status(200).json(results[0]);
    });
};

exports.methodNotAllowed = (req, res) => {
    res.status(405).json({ message: "Method not allowed" });
};
